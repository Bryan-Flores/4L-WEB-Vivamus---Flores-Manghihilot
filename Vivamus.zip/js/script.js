$(".h1").prop('hidden',false);
$(".p1").prop('hidden',false);
$(".h2").prop('hidden',true);
$(".p2").prop('hidden',true);
$(".h3").prop('hidden',true);
$(".p3").prop('hidden',true);
$(".content_main").prop('hidden',false);
$(".content_main2").prop('hidden',true);
$(".content_main3").prop('hidden',true);

const step_1 = document.getElementById('step_1');
// change text color to white
step_1.style.color = 'white';
// set background color to blue
step_1.style.background = '#2DA8C9';
// next function
$(".next_button").on('click',function(){
    var id = $(this).data('id');
    if(id == 1)
    {

        $(".h1").prop('hidden',true);
        $(".p1").prop('hidden',true);
        $(".h2").prop('hidden',false);
        $(".p2").prop('hidden',false);
        $(".h3").prop('hidden',true);
        $(".p3").prop('hidden',true);
        $(".content_main").prop('hidden',true);
        $(".content_main2").prop('hidden',false);
        $(".content_main3").prop('hidden',true);

        const step_1 = document.getElementById('step_1');
        // change text color to white
        step_1.style.color = '#2DA8C9';

        // set background color to blue
        step_1.style.background = 'white';

        const step_2 = document.getElementById('step_2');
        // change text color to white
        step_2.style.color = 'white';

        // set background color to blue
        step_2.style.background = '#2DA8C9';
    }
    else if(id == 2)
    {
        $(".h1").prop('hidden',true);
        $(".p1").prop('hidden',true);
        $(".h2").prop('hidden',true);
        $(".p2").prop('hidden',true);
        $(".h3").prop('hidden',false);
        $(".p3").prop('hidden',false);
        $(".content_main").prop('hidden',true);
        $(".content_main2").prop('hidden',true);
        $(".content_main3").prop('hidden',false);

        const step_2 = document.getElementById('step_2');
        // change text color to white
        step_2.style.color = '#2DA8C9';

        // set background color to blue
        step_2.style.background = 'white';

        const step_3 = document.getElementById('step_3');
        // change text color to white
        step_3.style.color = 'white';

        // set background color to blue
        step_3.style.background = '#2DA8C9';
    }
    else if(id == 3)
    {
    }
});
// back function
$(".back_button").on('click',function(){

    var id = $(this).data('id');

    if(id == 2)
    {
        $(".h1").prop('hidden',false);
        $(".p1").prop('hidden',false);
        $(".h2").prop('hidden',true);
        $(".p2").prop('hidden',true);
        $(".h3").prop('hidden',true);
        $(".p3").prop('hidden',true);

        $(".content_main").prop('hidden',false);
        $(".content_main2").prop('hidden',true);
        $(".content_main3").prop('hidden',true);
        const step_1 = document.getElementById('step_1');
        // change text color to white
        step_1.style.color = 'white';

        // set background color to blue
        step_1.style.background = '#2DA8C9';
        
        const step_2 = document.getElementById('step_2');
        // change text color to white
        step_2.style.color = '#2DA8C9';

        // set background color to blue
        step_2.style.background = 'white';
    }
    else if(id == 3)
    {
        $(".h1").prop('hidden',true);
        $(".p1").prop('hidden',true);
        $(".h2").prop('hidden',false);
        $(".p2").prop('hidden',false);
        $(".h3").prop('hidden',true);
        $(".p3").prop('hidden',true);

        $(".content_main").prop('hidden',true);
        $(".content_main2").prop('hidden',false);
        $(".content_main3").prop('hidden',true);

        const step_2 = document.getElementById('step_2');
        // change text color to white
        step_2.style.color = 'white';

        // set background color to blue
        step_2.style.background = '#2DA8C9';

        const step_3 = document.getElementById('step_3');
        // change text color to white
        step_3.style.color = '#2DA8C9';

        // set background color to blue
        step_3.style.background = 'white';
    }
});
$(document).ready(function(){
    $(".paypal").prop('hidden',false);
    $(".credit_card").prop('hidden',true);
})
$("#PayPal").on('click', function(){
    const title1 = document.getElementById('title1');
    title1.style.color = 'white ';
    title1.style.background = '#2DA8C9';
    const title2 = document.getElementById('title2');
    title2.style.color = '#2DA8C9';
    title2.style.background = '#fff';
    $(".paypal").prop('hidden',false);
    $(".credit_card").prop('hidden',true);
})
$("#CreditCard").on('click',function(){
    const title1 = document.getElementById('title1');
    title1.style.color = '#2DA8C9 ';
    title1.style.background = '#fff';
    const title2 = document.getElementById('title2');
    title2.style.color = 'white';
    title2.style.background = '#2DA8C9';
    $(".paypal").prop('hidden',true);
    $(".credit_card").prop('hidden',false);
})
